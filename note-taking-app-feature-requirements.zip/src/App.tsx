import { useState, useEffect, useCallback } from 'react';
import type { Notebook, Tool, ToolSettings, Page } from './types';
import { loadNotebooks, saveNotebooks, uid } from './store';
import Home from './components/Home';
import Editor from './components/Editor';

const defaultToolSettings: ToolSettings = {
  pen: { color: '#000000', size: 3 },
  highlighter: { color: '#fef08a', size: 12 },
  eraser: { size: 20 },
  text: { font: 'Arial', fontSize: 16, color: '#000000' },
};

function newPage(): Page {
  return { id: uid(), background: null, strokes: [], texts: [] };
}

function newNotebook(cover: string): Notebook {
  return { id: uid(), name: 'دفتر جديد', cover, pages: [newPage()], createdAt: Date.now() };
}

export default function App() {
  const [notebooks, setNotebooks] = useState<Notebook[]>(() => loadNotebooks());
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [tool, setTool] = useState<Tool>('pen');
  const [toolSettings, setToolSettings] = useState<ToolSettings>(defaultToolSettings);
  const [pageIndex, setPageIndex] = useState(0);

  useEffect(() => { saveNotebooks(notebooks); }, [notebooks]);

  const current = notebooks.find(n => n.id === currentId) || null;

  const createNotebook = (cover: string) => {
    const nb = newNotebook(cover);
    setNotebooks(prev => [nb, ...prev]);
    setCurrentId(nb.id);
    setPageIndex(0);
  };

  const deleteNotebook = (id: string) => {
    setNotebooks(prev => prev.filter(n => n.id !== id));
    if (currentId === id) setCurrentId(null);
  };

  const renameNotebook = (id: string, name: string) => {
    setNotebooks(prev => prev.map(n => n.id === id ? { ...n, name } : n));
  };

  const updateNotebook = useCallback((id: string, updater: (nb: Notebook) => Notebook) => {
    setNotebooks(prev => prev.map(n => n.id === id ? updater(n) : n));
  }, []);

  const addPage = () => {
    if (!current) return;
    updateNotebook(current.id, nb => ({ ...nb, pages: [...nb.pages, newPage()] }));
    setPageIndex(current.pages.length);
  };

  const deletePage = (idx: number) => {
    if (!current) return;
    if (current.pages.length <= 1) return;
    updateNotebook(current.id, nb => ({ ...nb, pages: nb.pages.filter((_, i) => i !== idx) }));
    setPageIndex(p => Math.max(0, Math.min(p, current.pages.length - 2)));
  };

  if (!current) {
    return (
      <Home
        notebooks={notebooks}
        onCreate={createNotebook}
        onOpen={(id: string) => { setCurrentId(id); setPageIndex(0); }}
        onDelete={deleteNotebook}
        onRename={renameNotebook}
      />
    );
  }

  return (
    <Editor
      notebook={current}
      pageIndex={pageIndex}
      setPageIndex={setPageIndex}
      tool={tool}
      setTool={setTool}
      toolSettings={toolSettings}
      setToolSettings={setToolSettings}
      updateNotebook={updateNotebook}
      addPage={addPage}
      deletePage={deletePage}
      onBack={() => setCurrentId(null)}
    />
  );
}