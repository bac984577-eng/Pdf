import { useState } from 'react';
import type { Notebook } from '../types';
import { COVER_COLORS } from '../store';
import { Plus, Trash2, BookOpen, Edit3 } from 'lucide-react';

interface Props {
  notebooks: Notebook[];
  onCreate: (cover: string) => void;
  onOpen: (id: string) => void;
  onDelete: (id: string) => void;
  onRename: (id: string, name: string) => void;
}

export default function Home({ notebooks, onCreate, onOpen, onDelete, onRename }: Props) {
  const [showCover, setShowCover] = useState(false);
  const [selectedCover, setSelectedCover] = useState(COVER_COLORS[0]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  const startRename = (nb: Notebook) => {
    setEditingId(nb.id);
    setEditName(nb.name);
  };
  const commitRename = () => {
    if (editingId) onRename(editingId, editName || 'دفتر');
    setEditingId(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 to-slate-200 p-6" dir="rtl">
      <div className="max-w-6xl mx-auto">
        <header className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-slate-800 flex items-center gap-2">
            <BookOpen className="w-8 h-8 text-blue-600" /> StarNote
          </h1>
          <button
            onClick={() => setShowCover(true)}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl shadow"
          >
            <Plus className="w-5 h-5" /> دفتر جديد
          </button>
        </header>

        {notebooks.length === 0 && (
          <div className="text-center text-slate-500 mt-20">
            <BookOpen className="w-16 h-16 mx-auto mb-4 opacity-40" />
            <p>لا توجد دفاتر. أنشئ دفترًا جديدًا.</p>
          </div>
        )}

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
          {notebooks.map(nb => (
            <div key={nb.id} className="group relative">
              <button
                onClick={() => onOpen(nb.id)}
                className="w-full aspect-[3/4] rounded-2xl shadow-lg hover:shadow-xl transition overflow-hidden border-4 border-white"
                style={{ background: nb.cover.startsWith('#') ? nb.cover : `url(${nb.cover}) center/cover` }}
              >
                <div className="absolute inset-0 bg-black/10" />
                <div className="absolute bottom-0 left-0 right-0 bg-white/90 p-2 text-center">
                  {editingId === nb.id ? (
                    <input
                      autoFocus
                      value={editName}
                      onChange={e => setEditName(e.target.value)}
                      onBlur={commitRename}
                      onKeyDown={e => e.key === 'Enter' && commitRename()}
                      className="w-full text-sm text-center border rounded px-1"
                    />
                  ) : (
                    <span className="text-sm font-medium text-slate-800 truncate block">{nb.name}</span>
                  )}
                </div>
              </button>
              <div className="absolute top-2 left-2 flex gap-1 opacity-0 group-hover:opacity-100 transition">
                <button onClick={() => startRename(nb)} className="bg-white/90 p-1.5 rounded-lg shadow" title="إعادة تسمية">
                  <Edit3 className="w-4 h-4 text-slate-700" />
                </button>
                <button onClick={() => onDelete(nb.id)} className="bg-white/90 p-1.5 rounded-lg shadow" title="حذف">
                  <Trash2 className="w-4 h-4 text-red-600" />
                </button>
              </div>
              <div className="text-xs text-slate-500 mt-1 text-center">{nb.pages.length} صفحة</div>
            </div>
          ))}
        </div>
      </div>

      {showCover && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowCover(false)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-md" onClick={e => e.stopPropagation()} dir="rtl">
            <h2 className="text-xl font-bold mb-4">اختر غلاف الدفتر</h2>
            <div className="grid grid-cols-5 gap-3 mb-4">
              {COVER_COLORS.map(c => (
                <button
                  key={c}
                  onClick={() => setSelectedCover(c)}
                  className={`w-12 h-16 rounded-lg border-4 transition ${selectedCover === c ? 'border-blue-500 scale-105' : 'border-transparent'}`}
                  style={{ background: c }}
                />
              ))}
            </div>
            <div className="flex gap-2">
              <input
                type="color"
                value={selectedCover.startsWith('#') ? selectedCover : '#1e3a8a'}
                onChange={e => setSelectedCover(e.target.value)}
                className="w-12 h-10 rounded cursor-pointer"
              />
              <label className="flex-1 bg-slate-100 hover:bg-slate-200 rounded-lg px-3 py-2 cursor-pointer text-center text-sm">
                صورة غلاف
                <input type="file" accept="image/*" className="hidden" onChange={e => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  const r = new FileReader();
                  r.onload = () => { setSelectedCover(r.result as string); };
                  r.readAsDataURL(f);
                }} />
              </label>
            </div>
            <div className="flex gap-2 mt-4">
              <button onClick={() => setShowCover(false)} className="flex-1 py-2 rounded-lg bg-slate-100">إلغاء</button>
              <button onClick={() => { onCreate(selectedCover); setShowCover(false); }} className="flex-1 py-2 rounded-lg bg-blue-600 text-white">إنشاء</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}