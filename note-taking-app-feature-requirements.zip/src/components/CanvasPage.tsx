import { useRef, useState, useEffect, useCallback } from 'react';
import type { Page, Stroke, TextBox, Tool, ToolSettings } from '../types';
import { uid } from '../store';

interface Props {
  page: Page;
  onChange: (page: Page) => void;
  tool: Tool;
  toolSettings: ToolSettings;
  width: number;
  height: number;
  selectedTextBoxId: string | null;
  onSelectTextBox: (id: string | null) => void;
  editingTextBoxId: string | null;
  setEditingTextBoxId: (id: string | null) => void;
}

const A4W = 794;
const A4H = 1123;

export { A4W, A4H };

export default function CanvasPage({
  page, onChange, tool, toolSettings, width, height,
  selectedTextBoxId, onSelectTextBox, editingTextBoxId, setEditingTextBoxId,
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawingRef = useRef(false);
  const currentStrokeRef = useRef<Stroke | null>(null);

  // Draw strokes to canvas
  const redraw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    // background image handled by div
    for (const s of page.strokes) {
      if (s.points.length < 2) continue;
      ctx.save();
      if (s.tool === 'eraser') {
        ctx.globalCompositeOperation = 'destination-out';
        ctx.strokeStyle = 'rgba(0,0,0,1)';
      } else if (s.tool === 'highlighter') {
        ctx.globalCompositeOperation = 'source-over';
        ctx.globalAlpha = 0.35;
        ctx.strokeStyle = s.color;
      } else {
        ctx.globalCompositeOperation = 'source-over';
        ctx.globalAlpha = 1;
        ctx.strokeStyle = s.color;
      }
      ctx.lineWidth = s.size;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(s.points[0].x, s.points[0].y);
      for (let i = 1; i < s.points.length; i++) ctx.lineTo(s.points[i].x, s.points[i].y);
      ctx.stroke();
      ctx.restore();
    }
  }, [page.strokes]);

  useEffect(() => { redraw(); }, [redraw, page.background]);

  // Scale factor
  const scale = width / A4W;

  const toCanvasCoords = (e: React.PointerEvent) => {
    const rect = canvasRef.current!.getBoundingClientRect();
    return { x: (e.clientX - rect.left) / scale, y: (e.clientY - rect.top) / scale };
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    if (tool === 'text' || tool === 'select' || tool === 'move') return;
    // drawing tools
    e.preventDefault();
    (e.target as any).setPointerCapture?.(e.pointerId);
    drawingRef.current = true;
    const pt = toCanvasCoords(e);
    const stroke: Stroke = {
      id: uid(),
      tool: tool as 'pen' | 'highlighter' | 'eraser',
      color: tool === 'eraser' ? '#000' : (tool === 'pen' ? toolSettings.pen.color : toolSettings.highlighter.color),
      size: tool === 'pen' ? toolSettings.pen.size : tool === 'highlighter' ? toolSettings.highlighter.size : toolSettings.eraser.size,
      points: [pt],
    };
    currentStrokeRef.current = stroke;
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!drawingRef.current || !currentStrokeRef.current) return;
    const pt = toCanvasCoords(e);
    currentStrokeRef.current.points.push(pt);
    // live redraw: append
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (ctx && canvas) {
      // redraw all for simplicity
      redraw();
      const s = currentStrokeRef.current;
      ctx.save();
      if (s.tool === 'eraser') { ctx.globalCompositeOperation = 'destination-out'; ctx.strokeStyle = 'rgba(0,0,0,1)'; }
      else if (s.tool === 'highlighter') { ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 0.35; ctx.strokeStyle = s.color; }
      else { ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1; ctx.strokeStyle = s.color; }
      ctx.lineWidth = s.size;
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.beginPath();
      const pts = s.points;
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
      ctx.stroke();
      ctx.restore();
    }
  };

  const handlePointerUp = () => {
    if (!drawingRef.current) return;
    drawingRef.current = false;
    const s = currentStrokeRef.current;
    if (s && s.points.length > 1) {
      onChange({ ...page, strokes: [...page.strokes, s] });
    }
    currentStrokeRef.current = null;
    redraw();
  };

  // Text box interactions
  const handlePaperClick = (e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    if (target.closest('[data-textbox]')) return;
    if (tool !== 'text') {
      onSelectTextBox(null);
      setEditingTextBoxId(null);
      return;
    }
    const rect = containerRef.current!.getBoundingClientRect();
    const x = (e.clientX - rect.left) / scale;
    const y = (e.clientY - rect.top) / scale;
    const tb: TextBox = {
      id: uid(),
      x, y, width: 200, height: 40,
      text: '',
      font: toolSettings.text.font,
      fontSize: toolSettings.text.fontSize,
      color: toolSettings.text.color,
      bold: false, italic: false,
    };
    onChange({ ...page, texts: [...page.texts, tb] });
    setEditingTextBoxId(tb.id);
    onSelectTextBox(tb.id);
  };

  const updateTextBox = (id: string, patch: Partial<TextBox>) => {
    onChange({ ...page, texts: page.texts.map(t => t.id === id ? { ...t, ...patch } : t) });
  };

  const deleteTextBox = (id: string) => {
    onChange({ ...page, texts: page.texts.filter(t => t.id !== id) });
    if (selectedTextBoxId === id) onSelectTextBox(null);
    if (editingTextBoxId === id) setEditingTextBoxId(null);
  };

  return (
    <div
      ref={containerRef}
      className="relative bg-white shadow-2xl mx-auto"
      style={{ width, height }}
      onClick={handlePaperClick}
    >
      {/* background */}
      {page.background && (
        <img src={page.background} alt="" className="absolute inset-0 w-full h-full object-cover pointer-events-none" />
      )}
      {/* strokes canvas */}
      <canvas
        ref={canvasRef}
        width={A4W}
        height={A4H}
        className="absolute inset-0"
        style={{ width: '100%', height: '100%', touchAction: 'none', cursor: tool === 'text' ? 'text' : tool === 'eraser' ? 'cell' : 'crosshair' }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
      />
      {/* text boxes */}
      {page.texts.map(tb => (
        <TextBoxView
          key={tb.id}
          tb={tb}
          scale={scale}
          selected={selectedTextBoxId === tb.id}
          editing={editingTextBoxId === tb.id}
          onSelect={() => onSelectTextBox(tb.id)}
          onEdit={() => setEditingTextBoxId(tb.id)}
          onStopEdit={() => setEditingTextBoxId(null)}
          onChange={(patch) => updateTextBox(tb.id, patch)}
          onDelete={() => deleteTextBox(tb.id)}
        />
      ))}
    </div>
  );
}

interface TBProps {
  tb: TextBox;
  scale: number;
  selected: boolean;
  editing: boolean;
  onSelect: () => void;
  onEdit: () => void;
  onStopEdit: () => void;
  onChange: (patch: Partial<TextBox>) => void;
  onDelete: () => void;
}

function TextBoxView({ tb, scale, selected, editing, onSelect, onEdit, onStopEdit, onChange, onDelete }: TBProps) {
  const [dragging, setDragging] = useState(false);
  const [resizing, setResizing] = useState(false);
  const editRef = useRef<HTMLDivElement>(null);
  const startRef = useRef<{ x: number; y: number; bx: number; by: number; bw: number; bh: number } | null>(null);

  // sync not needed

  useEffect(() => {
    if (editing && editRef.current) {
      editRef.current.innerText = tb.text || '';
      editRef.current.focus();
    }
  }, [editing]); // eslint-disable-line

  const handleMouseDown = (e: React.MouseEvent) => {
    if (editing) return;
    e.stopPropagation();
    onSelect();
    setDragging(true);
    startRef.current = { x: e.clientX, y: e.clientY, bx: tb.x, by: tb.y, bw: tb.width, bh: tb.height };
  };

  const handleDoubleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onEdit();
  };

  useEffect(() => {
    if (!dragging && !resizing) return;
    const onMove = (e: MouseEvent) => {
      const s = startRef.current;
      if (!s) return;
      if (dragging) {
        const dx = (e.clientX - s.x) / scale;
        const dy = (e.clientY - s.y) / scale;
        onChange({ x: s.bx + dx, y: s.by + dy });
      } else if (resizing) {
        const dx = (e.clientX - s.x) / scale;
        const dy = (e.clientY - s.y) / scale;
        onChange({ width: Math.max(60, s.bw + dx), height: Math.max(30, s.bh + dy) });
      }
    };
    const onUp = () => { setDragging(false); setResizing(false); };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
  }, [dragging, resizing, scale, onChange]);

  return (
    <div
      data-textbox
      onMouseDown={handleMouseDown}
      onDoubleClick={handleDoubleClick}
      style={{
        position: 'absolute',
        left: tb.x * scale,
        top: tb.y * scale,
        width: tb.width * scale,
        minHeight: tb.height * scale,
        fontFamily: tb.font,
        fontSize: tb.fontSize * scale,
        color: tb.color,
        fontWeight: tb.bold ? 'bold' : 'normal',
        fontStyle: tb.italic ? 'italic' : 'normal',
        cursor: editing ? 'text' : 'move',
        border: selected ? '2px dashed #2563eb' : '1px solid transparent',
        padding: 4 * scale,
        boxSizing: 'border-box',
        zIndex: 10,
        caretColor: '#2563eb',
      }}
      className="group"
    >
      {editing ? (
        <div
          ref={editRef}
          contentEditable
          suppressContentEditableWarning
          autoFocus
          onBlur={() => { onChange({ text: editRef.current?.innerText || '' }); onStopEdit(); }}
          style={{ outline: 'none', minHeight: '100%', whiteSpace: 'pre-wrap', caretColor: '#2563eb' }}
        />
      ) : (
        <div style={{ whiteSpace: 'pre-wrap', minHeight: '1em' }}>{tb.text || '\u00A0'}</div>
      )}
      {selected && !editing && (
        <>
          <button
            onClick={(e) => { e.stopPropagation(); onDelete(); }}
            className="absolute -top-3 -right-3 bg-red-500 text-white rounded-full w-5 h-5 text-xs flex items-center justify-center shadow"
            style={{ transform: `scale(${1/scale})`, transformOrigin: 'center' }}
          >×</button>
          <div
            onMouseDown={(e) => {
              e.stopPropagation();
              setResizing(true);
              startRef.current = { x: e.clientX, y: e.clientY, bx: tb.x, by: tb.y, bw: tb.width, bh: tb.height };
            }}
            className="absolute bottom-0 right-0 w-3 h-3 bg-blue-500 cursor-se-resize"
            style={{ transform: `scale(${1/scale})`, transformOrigin: 'bottom right' }}
          />
        </>
      )}
    </div>
  );
}