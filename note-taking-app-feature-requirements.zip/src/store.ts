import type { Notebook } from './types';

const KEY = 'starnote_notebooks_v1';

export function loadNotebooks(): Notebook[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    return JSON.parse(raw) as Notebook[];
  } catch {
    return [];
  }
}

export function saveNotebooks(nbs: Notebook[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(nbs));
  } catch (e) {
    console.error('save failed', e);
  }
}

export function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export const DEFAULT_FONTS = [
  'Arial', 'Times New Roman', 'Courier New', 'Georgia', 'Verdana',
  'Tahoma', 'Trebuchet MS', 'Comic Sans MS', 'Impact', 'Calibri',
];

export const COVER_COLORS = [
  '#1e3a8a', '#7c3aed', '#db2777', '#dc2626', '#ea580c',
  '#ca8a04', '#16a34a', '#0891b2', '#374151', '#000000',
];

export const PEN_COLORS = [
  '#000000', '#1e3a8a', '#dc2626', '#16a34a', '#7c3aed',
  '#ea580c', '#0891b2', '#db2777', '#ca8a04', '#374151',
];

export const HIGHLIGHT_COLORS = [
  '#fef08a', '#bbf7d0', '#bfdbfe', '#fecaca', '#e9d5ff',
  '#fed7aa', '#a5f3fc', '#fbcfe8',
];