import { useState, useRef, useCallback } from 'react';
import type { Notebook, Tool, ToolSettings, Page } from '../types';
import { PEN_COLORS, HIGHLIGHT_COLORS, DEFAULT_FONTS, COVER_COLORS } from '../store';
import CanvasPage from './CanvasPage';
import { jsPDF } from 'jspdf';
import {
  Pen, Highlighter, Eraser, Type, MousePointer2, Move, Trash2, Plus, Minus,
  ChevronLeft, ChevronRight, Download, Image as ImageIcon, Settings, X, BookOpen,
} from 'lucide-react';

interface Props {
  notebook: Notebook;
  pageIndex: number;
  setPageIndex: (i: number) => void;
  tool: Tool;
  setTool: (t: Tool) => void;
  toolSettings: ToolSettings;
  setToolSettings: (s: ToolSettings) => void;
  updateNotebook: (id: string, updater: (nb: Notebook) => Notebook) => void;
  addPage: () => void;
  deletePage: (idx: number) => void;
  onBack: () => void;
}

const PAGE_W = 794;
const PAGE_H = 1123;
// display scale
const DISPLAY_W = 600;

export default function Editor({
  notebook, pageIndex, setPageIndex, tool, setTool, toolSettings, setToolSettings,
  updateNotebook, addPage, deletePage, onBack,
}: Props) {
  const [selectedTextBoxId, setSelectedTextBoxId] = useState<string | null>(null);
  const [editingTextBoxId, setEditingTextBoxId] = useState<string | null>(null);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [colorTarget, setColorTarget] = useState<'pen' | 'highlighter' | 'text'>('pen');
  const [customColors, setCustomColors] = useState<string[]>([]);
  const [showSettings, setShowSettings] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [customFonts, setCustomFonts] = useState<string[]>([]);
  const [showCover, setShowCover] = useState(false);
  const [selectedCover, setSelectedCover] = useState(notebook.cover);
  const pageInputRef = useRef<HTMLInputElement>(null);

  const page = notebook.pages[pageIndex] || notebook.pages[0];

  const updatePage = useCallback((p: Page) => {
    updateNotebook(notebook.id, nb => ({
      ...nb, pages: nb.pages.map((pg, i) => i === pageIndex ? p : pg),
    }));
  }, [notebook.id, pageIndex, updateNotebook]);

  const handleAddCustomColor = (c: string) => {
    if (!customColors.includes(c)) setCustomColors(prev => [...prev, c]);
  };

  const importBackground = (file: File, scope: 'one' | 'all') => {
    const r = new FileReader();
    r.onload = () => {
      const data = r.result as string;
      updateNotebook(notebook.id, nb => ({
        ...nb,
        pages: nb.pages.map((pg, i) => (scope === 'all' || i === pageIndex) ? { ...pg, background: data } : pg),
      }));
    };
    r.readAsDataURL(file);
  };

  const exportPdf = async () => {
    setExporting(true);
    try {
      const pdf = new jsPDF({ orientation: 'portrait', unit: 'px', format: [PAGE_W, PAGE_H] });
      for (let i = 0; i < notebook.pages.length; i++) {
        const pg = notebook.pages[i];
        // create canvas
        const canvas = document.createElement('canvas');
        canvas.width = PAGE_W;
        canvas.height = PAGE_H;
        const ctx = canvas.getContext('2d')!;
        // background
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, PAGE_W, PAGE_H);
        if (pg.background) {
          await new Promise<void>((resolve) => {
            const img = new Image();
            img.onload = () => { ctx.drawImage(img, 0, 0, PAGE_W, PAGE_H); resolve(); };
            img.onerror = () => resolve();
            img.src = pg.background!;
          });
        }
        // strokes
        for (const s of pg.strokes) {
          if (s.points.length < 2) continue;
          ctx.save();
          if (s.tool === 'eraser') { ctx.globalCompositeOperation = 'destination-out'; ctx.strokeStyle = 'rgba(0,0,0,1)'; }
          else if (s.tool === 'highlighter') { ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 0.35; ctx.strokeStyle = s.color; }
          else { ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1; ctx.strokeStyle = s.color; }
          ctx.lineWidth = s.size;
          ctx.lineCap = 'round'; ctx.lineJoin = 'round';
          ctx.beginPath();
          ctx.moveTo(s.points[0].x, s.points[0].y);
          for (let j = 1; j < s.points.length; j++) ctx.lineTo(s.points[j].x, s.points[j].y);
          ctx.stroke();
          ctx.restore();
        }
        // text boxes
        for (const tb of pg.texts) {
          ctx.save();
          ctx.fillStyle = tb.color;
          ctx.font = `${tb.bold ? 'bold ' : ''}${tb.italic ? 'italic ' : ''}${tb.fontSize}px ${tb.font}`;
          const lines = tb.text.split('\n');
          lines.forEach((line, li) => {
            ctx.fillText(line, tb.x, tb.y + tb.fontSize + li * (tb.fontSize * 1.2));
          });
          ctx.restore();
        }
        const imgData = canvas.toDataURL('image/jpeg', 0.92);
        if (i > 0) pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, 0, PAGE_W, PAGE_H);
      }
      pdf.save(`${notebook.name || 'notebook'}.pdf`);
    } catch (e) {
      console.error(e);
      alert('فشل التصدير');
    } finally {
      setExporting(false);
    }
  };

  const colorList = (target: 'pen' | 'highlighter' | 'text') => {
    if (target === 'highlighter') return [...HIGHLIGHT_COLORS, ...customColors];
    return [...PEN_COLORS, ...customColors];
  };

  const currentColor = tool === 'pen' ? toolSettings.pen.color
    : tool === 'highlighter' ? toolSettings.highlighter.color
    : toolSettings.text.color;

  const setCurrentColor = (c: string) => {
    if (tool === 'pen') setToolSettings({ ...toolSettings, pen: { ...toolSettings.pen, color: c } });
    else if (tool === 'highlighter') setToolSettings({ ...toolSettings, highlighter: { ...toolSettings.highlighter, color: c } });
    else setToolSettings({ ...toolSettings, text: { ...toolSettings.text, color: c } });
  };

  const currentSize = tool === 'pen' ? toolSettings.pen.size
    : tool === 'highlighter' ? toolSettings.highlighter.size
    : tool === 'eraser' ? toolSettings.eraser.size
    : toolSettings.text.fontSize;

  const setCurrentSize = (v: number) => {
    if (tool === 'pen') setToolSettings({ ...toolSettings, pen: { ...toolSettings.pen, size: v } });
    else if (tool === 'highlighter') setToolSettings({ ...toolSettings, highlighter: { ...toolSettings.highlighter, size: v } });
    else if (tool === 'eraser') setToolSettings({ ...toolSettings, eraser: { size: v } });
    else setToolSettings({ ...toolSettings, text: { ...toolSettings.text, fontSize: v } });
  };

  return (
    <div className="min-h-screen bg-slate-200 flex flex-col" dir="rtl">
      {/* Top bar */}
      <div className="bg-white shadow px-4 py-2 flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-2 rounded-lg hover:bg-slate-100" title="رجوع">
            <ChevronRight className="w-5 h-5" />
          </button>
          <input
            value={notebook.name}
            onChange={e => updateNotebook(notebook.id, nb => ({ ...nb, name: e.target.value }))}
            className="font-bold text-slate-800 border-b border-transparent hover:border-slate-300 focus:border-blue-500 outline-none px-1"
          />
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => pageInputRef.current?.click()} className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200" title="خلفية">
            <ImageIcon className="w-5 h-5" />
          </button>
          <button onClick={() => { setSelectedCover(notebook.cover); setShowCover(true); }} className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200" title="غلاف">
            <BookOpen className="w-5 h-5" />
          </button>
          <input ref={pageInputRef} type="file" accept="image/*" className="hidden" onChange={e => {
            const f = e.target.files?.[0];
            if (!f) return;
            // ask scope
            const scope = window.confirm('نعم = جميع الصفحات، إلغاء = هذه الصفحة فقط') ? 'all' : 'one';
            importBackground(f, scope);
            e.target.value = '';
          }} />
          <button onClick={exportPdf} disabled={exporting} className="p-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50" title="تصدير PDF">
            <Download className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="bg-white shadow-sm px-4 py-2 flex items-center gap-2 flex-wrap justify-center">
        <ToolBtn icon={Pen} active={tool === 'pen'} onClick={() => setTool('pen')} title="قلم" />
        <ToolBtn icon={Highlighter} active={tool === 'highlighter'} onClick={() => setTool('highlighter')} title="محدد" />
        <ToolBtn icon={Eraser} active={tool === 'eraser'} onClick={() => setTool('eraser')} title="ممحاة" />
        <ToolBtn icon={Type} active={tool === 'text'} onClick={() => setTool('text')} title="نص" />
        <ToolBtn icon={MousePointer2} active={tool === 'select'} onClick={() => setTool('select')} title="تحديد" />
        <ToolBtn icon={Move} active={tool === 'move'} onClick={() => setTool('move')} title="نقل" />

        <div className="w-px h-6 bg-slate-300 mx-1" />

        {/* color */}
        {(tool === 'pen' || tool === 'highlighter' || tool === 'text') && (
          <div className="flex items-center gap-1">
            <button
              onClick={() => { setColorTarget(tool === 'text' ? 'text' : tool === 'highlighter' ? 'highlighter' : 'pen'); setShowColorPicker(v => !v); }}
              className="w-8 h-8 rounded-full border-2 border-slate-300 shadow"
              style={{ background: currentColor }}
              title="لون"
            />
            <button
              onClick={() => {
                const c = prompt('أدخل لون (hex):', '#ff0000');
                if (c) { handleAddCustomColor(c); setCurrentColor(c); }
              }}
              className="w-8 h-8 rounded-full border-2 border-dashed border-slate-400 flex items-center justify-center text-slate-500 hover:bg-slate-100"
              title="لون إضافي"
            >+</button>
          </div>
        )}

        {/* size */}
        <div className="flex items-center gap-1">
          <button onClick={() => setCurrentSize(Math.max(1, currentSize - (tool === 'text' ? 2 : 1)))} className="p-1 rounded hover:bg-slate-100"><Minus className="w-4 h-4" /></button>
          <span className="text-xs w-8 text-center">{currentSize}</span>
          <button onClick={() => setCurrentSize(currentSize + (tool === 'text' ? 2 : 1))} className="p-1 rounded hover:bg-slate-100"><Plus className="w-4 h-4" /></button>
          <input
            type="range"
            min={tool === 'text' ? 8 : 1}
            max={tool === 'text' ? 72 : tool === 'eraser' ? 60 : 40}
            value={currentSize}
            onChange={e => setCurrentSize(Number(e.target.value))}
            className="w-24"
          />
        </div>

        {/* text font */}
        {tool === 'text' && (
          <>
            <select
              value={toolSettings.text.font}
              onChange={e => setToolSettings({ ...toolSettings, text: { ...toolSettings.text, font: e.target.value } })}
              className="text-sm border rounded px-2 py-1"
            >
              {DEFAULT_FONTS.map(f => <option key={f} value={f}>{f}</option>)}
              {customFonts.map(f => <option key={f} value={f}>{f}</option>)}
            </select>
            <label className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs cursor-pointer">
              استيراد خط
              <input type="file" accept=".ttf,.otf,.woff,.woff2" className="hidden" onChange={async (e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                const name = f.name.replace(/\.[^.]+$/, '');
                const url = URL.createObjectURL(f);
                try {
                  const ff = new FontFace(name, `url(${url})`);
                  await ff.load();
                  (document.fonts as any).add(ff);
                  setCustomFonts(prev => prev.includes(name) ? prev : [...prev, name]);
                  setToolSettings({ ...toolSettings, text: { ...toolSettings.text, font: name } });
                } catch (err) {
                  console.error(err);
                  alert('فشل استيراد الخط');
                }
                e.target.value = '';
              }} />
            </label>
          </>
        )}

        <button onClick={() => setShowSettings(v => !v)} className="p-2 rounded-lg hover:bg-slate-100" title="إعدادات">
          <Settings className="w-5 h-5" />
        </button>
      </div>

      {/* Color picker popup */}
      {showColorPicker && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 bg-white shadow-xl rounded-xl p-3 z-40" dir="rtl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">الألوان</span>
            <button onClick={() => setShowColorPicker(false)}><X className="w-4 h-4" /></button>
          </div>
          <div className="grid grid-cols-8 gap-2">
            {colorList(colorTarget).map(c => (
              <button
                key={c}
                onClick={() => { setCurrentColor(c); }}
                className={`w-7 h-7 rounded-full border-2 ${currentColor === c ? 'border-blue-500 scale-110' : 'border-slate-200'}`}
                style={{ background: c }}
              />
            ))}
          </div>
          <div className="mt-2 flex gap-2">
            <input type="color" onChange={e => { handleAddCustomColor(e.target.value); setCurrentColor(e.target.value); }} className="w-10 h-8 rounded cursor-pointer" />
            <span className="text-xs text-slate-500 self-center">لون مخصص</span>
          </div>
        </div>
      )}

      {/* Settings panel */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50" onClick={() => setShowSettings(false)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm" onClick={e => e.stopPropagation()} dir="rtl">
            <h3 className="font-bold mb-3">إعدادات الأداة</h3>
            <p className="text-sm text-slate-600 mb-2">القلم: حجم {toolSettings.pen.size}, لون</p>
            <p className="text-sm text-slate-600 mb-2">المحدد: حجم {toolSettings.highlighter.size}</p>
            <p className="text-sm text-slate-600 mb-2">الممحاة: حجم {toolSettings.eraser.size}</p>
            <p className="text-sm text-slate-600 mb-2">النص: {toolSettings.text.font} {toolSettings.text.fontSize}px</p>
            <button onClick={() => setShowSettings(false)} className="mt-3 w-full py-2 bg-blue-600 text-white rounded-lg">إغلاق</button>
          </div>
        </div>
      )}

      {/* Page area */}
      <div className="flex-1 overflow-auto p-6 flex flex-col items-center gap-4">
        <CanvasPage
          page={page}
          onChange={updatePage}
          tool={tool}
          toolSettings={toolSettings}
          width={DISPLAY_W}
          height={DISPLAY_W * (PAGE_H / PAGE_W)}
          selectedTextBoxId={selectedTextBoxId}
          onSelectTextBox={setSelectedTextBoxId}
          editingTextBoxId={editingTextBoxId}
          setEditingTextBoxId={setEditingTextBoxId}
        />

        {/* page nav */}
        <div className="flex items-center gap-3 bg-white rounded-xl shadow px-4 py-2">
          <button
            onClick={() => setPageIndex(Math.max(0, pageIndex - 1))}
            disabled={pageIndex === 0}
            className="p-1 rounded hover:bg-slate-100 disabled:opacity-30"
          ><ChevronRight className="w-5 h-5" /></button>
          <span className="text-sm">صفحة {pageIndex + 1} / {notebook.pages.length}</span>
          <button
            onClick={() => setPageIndex(Math.min(notebook.pages.length - 1, pageIndex + 1))}
            disabled={pageIndex === notebook.pages.length - 1}
            className="p-1 rounded hover:bg-slate-100 disabled:opacity-30"
          ><ChevronLeft className="w-5 h-5" /></button>
          <button onClick={addPage} className="p-2 rounded-lg bg-blue-600 text-white" title="صفحة جديدة">
            <Plus className="w-4 h-4" />
          </button>
          <button
            onClick={() => deletePage(pageIndex)}
            disabled={notebook.pages.length <= 1}
            className="p-2 rounded-lg bg-red-500 text-white disabled:opacity-30" title="حذف صفحة"
          ><Trash2 className="w-4 h-4" /></button>
        </div>
      </div>

      {showCover && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowCover(false)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-md" onClick={e => e.stopPropagation()} dir="rtl">
            <h2 className="text-xl font-bold mb-4">اختر غلاف الدفتر</h2>
            <div className="grid grid-cols-5 gap-3 mb-4">
              {COVER_COLORS.map(c => (
                <button
                  key={c}
                  onClick={() => setSelectedCover(c)}
                  className={`w-12 h-16 rounded-lg border-4 transition ${selectedCover === c ? 'border-blue-500 scale-105' : 'border-transparent'}`}
                  style={{ background: c }}
                />
              ))}
            </div>
            <div className="flex gap-2">
              <input
                type="color"
                value={selectedCover.startsWith('#') ? selectedCover : '#1e3a8a'}
                onChange={e => setSelectedCover(e.target.value)}
                className="w-12 h-10 rounded cursor-pointer"
              />
              <label className="flex-1 bg-slate-100 hover:bg-slate-200 rounded-lg px-3 py-2 cursor-pointer text-center text-sm">
                صورة غلاف
                <input type="file" accept="image/*" className="hidden" onChange={e => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  const r = new FileReader();
                  r.onload = () => { setSelectedCover(r.result as string); };
                  r.readAsDataURL(f);
                }} />
              </label>
            </div>
            <div className="flex gap-2 mt-4">
              <button onClick={() => setShowCover(false)} className="flex-1 py-2 rounded-lg bg-slate-100">إلغاء</button>
              <button onClick={() => { updateNotebook(notebook.id, nb => ({ ...nb, cover: selectedCover })); setShowCover(false); }} className="flex-1 py-2 rounded-lg bg-blue-600 text-white">حفظ</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ToolBtn({ icon: Icon, active, onClick, title }: any) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={`p-2 rounded-lg transition ${active ? 'bg-blue-600 text-white' : 'hover:bg-slate-100 text-slate-700'}`}
    >
      <Icon className="w-5 h-5" />
    </button>
  );
}