export type Tool = 'pen' | 'highlighter' | 'eraser' | 'text' | 'select' | 'move';

export interface Point { x: number; y: number; }

export interface Stroke {
  id: string;
  tool: 'pen' | 'highlighter' | 'eraser';
  color: string;
  size: number;
  points: Point[];
}

export interface TextBox {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  text: string;
  font: string;
  fontSize: number;
  color: string;
  bold: boolean;
  italic: boolean;
}

export interface Page {
  id: string;
  background: string | null; // data URL
  strokes: Stroke[];
  texts: TextBox[];
}

export interface Notebook {
  id: string;
  name: string;
  cover: string; // color or dataURL
  pages: Page[];
  createdAt: number;
}

export interface ToolSettings {
  pen: { color: string; size: number };
  highlighter: { color: string; size: number };
  eraser: { size: number };
  text: { font: string; fontSize: number; color: string };
}